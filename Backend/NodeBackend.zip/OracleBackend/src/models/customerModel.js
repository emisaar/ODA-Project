class Customer {
    constructor(id, name, age, ssn, occupation, annualIncome, monthlyInhandSalary, numBankAccounts, numCreditCard) {
        this.id = id;
        this.name = name;
        this.age = age;
        this.ssn = ssn;
        this.occupation = occupation;
        this.annualIncome = annualIncome;
        this.monthlyInhandSalary = monthlyInhandSalary;
        this.numBankAccounts = numBankAccounts;
        this.numCreditCard = numCreditCard;
    }
  }
  
export default Customer;