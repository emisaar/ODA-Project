from flask import Flask, jsonify
from aiService import classify_document, inspect_document

app = Flask(__name__)

# Define an endpoint
@app.route('/api/greet', methods=['GET'])
def greet():
    """Return a friendly HTTP greeting."""
    return jsonify({'message': 'Hello, Flask API!'})

# Define an endpoint
@app.route('/api/ai-service/custom-model/document-classification', methods=['POST'])
def document_classification():
    """Return Oracle classification model response."""
    return classify_document()

# Define an endpoint
@app.route('/api/ai-service/custom-model/process-document', methods=['POST'])
def process_document():
    """Return Oracle key value extraction model response."""
    return inspect_document()

if __name__ == '__main__':
    app.run(debug=True)
