# coding: utf-8
# Copyright (c) 2016, 2021, Oracle and/or its affiliates.  All rights reserved.
# This software is dual-licensed to you under the Universal Permissive License (UPL) 1.0 as shown at https://oss.oracle.com/licenses/upl or Apache License 2.0 as shown at http://www.apache.org/licenses/LICENSE-2.0. You may choose either license.

##########################################################################
# object_storage_key_value_extraction_demo.py
#
# Supports Python 3
##########################################################################
# Info:
# Object Storage Key Value extraction Processor Job creation using OCI AI Document Understanding service.
#
##########################################################################
# Application Command line(no parameter needed)
# python object_storage_key_value_extraction_demo.py
##########################################################################

"""
This python script provides an example of how to use OCI Document Understanding Service key value extraction feature.

The configuration file used by service clients will be sourced from the default location (~/.oci/config) and the
CONFIG_PROFILE profile will be used.

The sample attempts to extract key fields from an invoice document in object storage.
Successful run of this sample will create job results under object storage configured under output_location variable
"""
import uuid
import oci  # oci python sdk
from flask import request, jsonify, make_response
import json

# Setup basic variables
# Auth Config
CONFIG_PROFILE = "DEFAULT"
config = oci.config.from_file('~/.oci/config', CONFIG_PROFILE)
COMPARTMENT_ID = "ocid1.tenancy.oc1..aaaaaaaaw23kqle6g4sesdfdqyozydjd4tbu5pi5tccbmqqy3lptn4vv4oqa"  # e.g. "ocid1.compartment.oc1..aaaaaaaae5j73axsja5fnahbn23ilop3ynjkcg77mcvgryddz4pkh2t5ppaq";

aiservicedocument_client = oci.ai_document.AIServiceDocumentClientCompositeOperations(oci.ai_document.AIServiceDocumentClient(config=config))
key_value_extraction_feature = oci.ai_document.models.DocumentKeyValueExtractionFeature()
document_classification_feature = oci.ai_document.models.DocumentClassificationFeature()

def define_object_location(file_name):
    """ Define object location where document being processed is stored. """
    # Setup input location where document being processed is stored.
    object_location = oci.ai_document.models.ObjectLocation()
    object_location.namespace_name = "axioynhey0yi"  # e.g. "axhh9gizbq5x"
    object_location.bucket_name = "tutorial-bucket"  # e.g "demo_examples"
    object_location.object_name = file_name  # e.g "key_value_extraction_demo.jpg"
    return object_location

def define_output_location(prefix):
    """ Define output location where processor job results will be created. """
    # Setup the output location where processor job results will be created
    output_location = oci.ai_document.models.OutputLocation()
    output_location.namespace_name = "axioynhey0yi"  # e.g. "axk2tfhlrens"
    output_location.bucket_name = "tutorial-bucket"  # e.g "output"
    output_location.prefix = prefix  # e.g "demo"
    return output_location

def create_processor_job_callback(times_called, response):
    """ Callback function to check processor job status. """
    print("Waiting for processor lifecycle state to go into succeeded state:", response.data)

def run_model(object_location, output_location, additional_feature):
    """ Run key value extraction model. """
    # Create a processor_job for invoice key_value_extraction feature. 
    # Note: If you want to use another key value extraction feature, set document_type to "RECIEPT" "PASSPORT" or "DRIVER_ID". If you have a mix of document types, you can remove document_type
    create_processor_job_details_key_value_extraction = oci.ai_document.models.CreateProcessorJobDetails(
                                                        display_name=str(uuid.uuid4()),
                                                        compartment_id=COMPARTMENT_ID,
                                                        input_location=oci.ai_document.models.ObjectStorageLocations(object_locations=[object_location]),
                                                        output_location=output_location,
                                                        processor_config=oci.ai_document.models.GeneralProcessorConfig(features=[additional_feature])) #TODO: check if works or [key_value_extraction_feature, additional_feature]

    # print("Calling create_processor with create_processor_job_details_key_value_extraction:", create_processor_job_details_key_value_extraction)
    create_processor_response = aiservicedocument_client.create_processor_job_and_wait_for_state(
        create_processor_job_details=create_processor_job_details_key_value_extraction,
        wait_for_states=[oci.ai_document.models.ProcessorJob.LIFECYCLE_STATE_SUCCEEDED],
        waiter_kwargs={"wait_callback": create_processor_job_callback})

    # print("processor call succeeded with status: {} and request_id: {}.".format(create_processor_response.status, create_processor_response.request_id))
    processor_job: oci.ai_document.models.ProcessorJob = create_processor_response.data
    # print("create_processor_job_details_key_value_extraction response: ", create_processor_response.data)

    # print("Getting defaultObject.json from the output_location")
    object_storage_client = oci.object_storage.ObjectStorageClient(config=config)
    get_object_response = object_storage_client.get_object(namespace_name=output_location.namespace_name,
                                                        bucket_name=output_location.bucket_name,
                                                        object_name="{}/{}/{}_{}/results/{}.json".format(
                                                            output_location.prefix, processor_job.id,
                                                            object_location.namespace_name,
                                                            object_location.bucket_name,
                                                            object_location.object_name))
    # object_name="{}/{}/{}_{}/results/{}.json".format(
    #                                                         output_location.prefix, processor_job.id,
    #                                                         object_location.namespace_name,
    #                                                         object_location.bucket_name,
    #                                                         object_location.object_name))
    
    return get_object_response

def classify_document():
    data = json.loads(request.data)
    print("PAYLOAD", data)
    object_location = define_object_location(data['file'])
    output_location = define_output_location("pythonResponse/DC")

    additional_feature = {
        "modelId": "ocid1.aidocumentmodel.oc1.phx.amaaaaaa3ee77waaoxj2dnynm2rphg6ugv2vbq75eabv5hktu67ayvgimwwq",
        "featureType": "DOCUMENT_CLASSIFICATION"
    }

    get_object_response = run_model(object_location, output_location, additional_feature)
    if get_object_response.status != 200:
        raise Exception("Failed to get object from object storage. Status: {}, Message: {}".format(get_object_response.status, get_object_response.data))
    # Process response to a shorter response with necessary data
    model_response = json.loads(get_object_response.data.content.decode())
    response = model_response.get('detectedDocumentTypes')[0].get('documentType')
    return jsonify({'document_type': response})

def inspect_document():
    data = json.loads(request.data)
    print("PAYLOAD", data)
    object_location = define_object_location(data['file'])
    output_location = define_output_location("pythonResponse/KVE")

    if data['document_type'] == 'Constancia Fiscal':
        # Additional feature you want to add
        additional_feature = {
            "modelId": "ocid1.aidocumentmodel.oc1.phx.amaaaaaa3ee77waa655eb4yfkatx7ryip55oiltn2ruwulumzj5rmkyqbkfq",
            "featureType": "KEY_VALUE_EXTRACTION"
        }
        # Path to the output location where processor job results will be created
        output_location.prefix = "pythonResponse/KVE/CF"  # e.g "demo"
    elif data['document_type'] == 'INE':
        # Additional feature you want to add
        additional_feature = {
            "modelId": "ocid1.aidocumentmodel.oc1.phx.amaaaaaa3ee77waa3k3jto3s34m2j54gkdshl6k365vxa4rdb2w63uhwjr2q",
            "featureType": "KEY_VALUE_EXTRACTION"
        }
        # Path to the output location where processor job results will be created
        output_location.prefix = "pythonResponse/KVE/INE"
    elif data['document_type'] == 'CFE':
        # Additional feature you want to add
        additional_feature = {
            "modelId": "ocid1.aidocumentmodel.oc1.phx.amaaaaaa3ee77waazetzrjgcrtrbyz3ijpwt56tyb3jjey6cohuvwfphmmya",
            "featureType": "KEY_VALUE_EXTRACTION"
        }
        # Path to the output location where processor job results will be created
        output_location.prefix = "pythonResponse/KVE/CFE"
    else:
        return jsonify({'message': 'Document type not supported'})

    get_object_response = run_model(object_location, output_location, additional_feature)

    if get_object_response.status != 200:
        raise Exception("Failed to get object from object storage. Status: {}, Message: {}".format(get_object_response.status, get_object_response.data))
    
    processed_response = {}
    keys = ['name', 'surname1', 'surname2', 'postal_code', 'town', 'state']
    # Process response to a shorter response with necessary data
    model_response = json.loads(get_object_response.data.content.decode())
    response = model_response.get('pages')[0].get('documentFields')
    # loop object array
    for dictionary in response:
        field_label = dictionary['fieldLabel']
        name = field_label['name']
        field_value = dictionary['fieldValue']
        value = field_value['value']

        if name == 'postal_code' and data['document_type'] == 'CF':
            substring_to_remove = "Postal:"
            value = value.replace(substring_to_remove, "")

        processed_response[name] = value
    
    # check keys of processed_response
    for key in keys:
        if key not in processed_response:
            response = jsonify({'message': 'Document not valid'})
            return make_response(response, 400)
        
    return processed_response 